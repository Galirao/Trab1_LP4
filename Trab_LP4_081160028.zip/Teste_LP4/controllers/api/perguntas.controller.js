
  var config = require('config.json');
var express = require('express');
var router = express.Router();
var PerguntasService = require('services/perguntas.controller');

// routes

router.post('/perguntas', SalvaPergunta);


module.exports = router;

function SalvaPergunta(req, res) {
    PerguntasService.createPergunta()
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
