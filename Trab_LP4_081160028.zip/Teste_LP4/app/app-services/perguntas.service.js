(function () {
    'use strict';

    angular
        .module('app')
        .factory('PerguntasService', Service);

    function Service() {
        var service = {};

      
        service.createPergunta = createPergunta;
     
        function createPergunta() {
            return console.log("a");
        }
        

}});
